// Included libraries
#include "Mesh_Read.h"

/********************************************************************
// Unstructured Mesh Programming Assignment Field Functions File Header
// Mech 588 - Advanced CFD UBC Mechanical Engineering Winter 2023
// Christian Rowsell (40131393)
********************************************************************/

#ifndef FIELD_FUNCTIONS_H

#define FIELD_FUNCTIONS_H

void initial_condition(const Mesh &mesh, std::vector<double> &temp_cent, std::array<std::vector<double>, 2> &vel);
void save_VTK(std::string fileName, const Mesh mesh, const std::vector<double> temp_cent);
void calc_grad(const Mesh mesh, std::vector<double> temp_cent, std::array<std::vector<double>, 2> &Cell_Grad);
void calc_upwind(Mesh &mesh, std::array<std::vector<double>, 2> vel);
void calc_flux(Mesh &mesh, std::vector<double> temp_cent, std::array<std::vector<double>, 2> Cell_Grad, std::vector<double> &Edge_flux);
void calc_flux_integral(Mesh mesh, std::vector<double> Edge_flux, std::vector<double> &Cell_Flux_Integral);
double calc_L2Norm(std::vector<double> vector);
void euler(Mesh mesh, std::vector<double> &Temp, std::vector<double> &flux_curr, double &dt);
void adams_bashforth(Mesh mesh, std::vector<double> &Temp, std::vector<double> &flux_curr, std::vector<double> &flux_prev, double &dt, int itime);
void midpoint(Mesh mesh, std::vector<double> &Temp, std::vector<double> &flux_curr, double &dt);
void RK2(Mesh mesh, std::vector<double> &Temp, std::vector<double> &flux_curr, double &dt);

#endif