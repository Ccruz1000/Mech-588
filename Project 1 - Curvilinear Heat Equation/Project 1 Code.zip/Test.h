#include "Fcurv.h"
/********************************************************************
// Curvillinear Mesh Programming Assignment Test Header File
// Mech 588 - Advanced CFD UBC Mechanical Engineering Winter 2023
// Christian Rowsell (40131393)
********************************************************************/

#ifndef TEST_H
#define TEST_H

void test_void_constructor();
void test_constructor();
void test_mesh_read(std::string meshname);

#endif