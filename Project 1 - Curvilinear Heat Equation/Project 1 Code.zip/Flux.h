#include "Fcurv.h"

/********************************************************************
// Curvillinear Mesh Programming Assignment Flux Integral File Header
// Mech 588 - Advanced CFD UBC Mechanical Engineering Winter 2023
// Christian Rowsell (40131393)
********************************************************************/

#ifndef FLUX_H

#define FLUX_H

void calc_flux(Vector &I, Solution &s);


#endif