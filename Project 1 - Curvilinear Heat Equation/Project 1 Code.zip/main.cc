#include "Fcurv.h"

/********************************************************************
// Curvillinear Mesh Programming Assignment Main File
// Mech 588 - Advanced CFD UBC Mechanical Engineering Winter 2023
// Christian Rowsell (40131393)
********************************************************************/

int main()
{
	std::cout << "Hello\n";
	return 0;
}
